#!/bin/bash
LD_LIBRARY_PATH=. ./FUGE-LC
