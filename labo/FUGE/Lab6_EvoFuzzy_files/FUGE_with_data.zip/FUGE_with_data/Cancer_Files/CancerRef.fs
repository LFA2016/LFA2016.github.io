/* FUGE-LC Reference script 

	Author: JPA, HSL
	Date  : 04-2016

 	Note: the name of the functions cannot be changed 							
*/

// Experiment name appearing in the logs
experimentName = "Cancer2016";

// Directory where logs, fuzzy systems and temporary files are saved
savePath = "/home/lfa/Desktop/FUGE_with_data/test";

// Fuzzy system parameters 
fixedVars = false;
nbRules = 5;
nbMaxVarPerRule = 5;
nbOutVars = 1;
nbInSets = 2;
nbOutSets = 2;
inVarsCodeSize = 5;
outVarsCodeSize = 1;
inSetsCodeSize = 2;
outSetsCodeSize = 1;
inSetsPosCodeSize = 6;
outSetPosCodeSize = 1;

// Co-evolution parameters
// Population 1: Membership Functions (Variables)
maxGenPop1 = 400;
maxFitPop1 = 0.99;
elitePop1 = 5;
popSizePop1 = 100;
cxProbPop1 = 0.9;
mutFlipIndPop1 = 0.2;
mutFlipBitPop1 = 0.01;

// Population 2: Rules
elitePop2 = 5;
popSizePop2 = 100;
cxProbPop2 = 0.6;
mutFlipIndPop2 = 0.4;
mutFlipBitPop2 = 0.01;

// Fitness parameters
sensitivityW = 1.0;
specificityW = 0.8;
accuracyW = 0.0;
ppvW = 0.0;
rmseW = 0.1;
rrseW = 0.0;
raeW = 0.0;
mxeW = 0.0;
distanceThresholdW = 0.0;
distanceMinThresholdW = 0.0;
dontCareW = 0.1;
overLearnW = 0.0;
threshold = 0.5;
threshActivated = true;

function doSetParams()
{
	this.setParams(experimentName, savePath, fixedVars, nbRules, nbMaxVarPerRule, nbOutVars, nbInSets, nbOutSets, inVarsCodeSize, outVarsCodeSize, 
				 inSetsCodeSize, outSetsCodeSize, inSetsPosCodeSize, outSetPosCodeSize, maxGenPop1, maxFitPop1, elitePop1, popSizePop1, 
				 cxProbPop1, mutFlipIndPop1, mutFlipBitPop1, maxGenPop1, maxFitPop1, elitePop2, popSizePop2, cxProbPop2, mutFlipIndPop2, 
				 mutFlipBitPop2, sensitivityW, specificityW, accuracyW, ppvW, rmseW, rrseW, raeW, mxeW, distanceThresholdW,
			         distanceMinThresholdW, dontCareW, overLearnW, threshold, threshActivated);
}

// Run function called by FUGE-LC. This function MUST also be present
function doRun() 
{
	var nRuleVals = [2,3,5,7];
	var popVals = [100, 200];

	// Multiple coevolution runs with different parameters
	for (var i = 0; i < nRuleVals.length; i++) {
		for (var j = 0; j < popVals.length; j++) {
			for (var n = 0; n < 3; n++) {
				nbRules = nRuleVals[i];
				popSizePop1 = popVals[j];
				popSizePop2 = popVals[j];			
				this.runEvo();
			}
		}
	}
}
// EOF
